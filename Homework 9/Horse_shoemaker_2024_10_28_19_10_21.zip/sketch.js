function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(86, 130, 126);
  strokeWeight(2)
  stroke(0)
  fill(222, 205, 186);
  rect(145,225,60,75);
  ellipse(175,175,125,150);
  fill(64, 38, 16);
  triangle(100, 260, 175, 350, 250, 260);
  line(175,350,175,400);
  line(100,260,50,350);
  line(250,260,310,350);
  line(310,350,310,400);
  line(50,350,50,400);
  circle(140,170,20);
  circle(210,170,20);
  fill(194, 164, 149);
  square(165,180,20);
  fill(1, 110, 77);
  triangle(120,130,100,250,150,125);
  triangle(120,130,250,175,160,90);
  triangle(250,130,250,250,165,90);
  textSize(20)
  text('Elizabeth',150,40)
  strokeWeight(8);
  point(175,225);
  strokeWeight(5)
  stroke (239,195,98);
  line(125,185,150,185);
  line(125,185,120,165);
  line(155,165,150,185);
  line(200,185,225,185);
  line(200,185,195,165);
  line(230,165,225,185);
  
}