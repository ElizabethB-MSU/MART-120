var charX = 250;
var charY = 300;

var enemyX=50;
var enemyY=50;
var shapeXSpeed;
var shapeYSpeed;

var mousex=100;
var mousey=650;

function setup() {
  createCanvas(500, 600);
}

function draw() {
  background(100);
  stroke(50);
    fill(50);
  
  //border
    rect(0,0,width,10);
    rect(0,0,10,height);
    rect(0, height-10,width, 10);
    rect(width-10,0,10,height-90);
  
  //Mouse coordinates (Delete later)
  strokeWeight(3)
    stroke(255);
    fill(126,175,162);
   text("X: " + mouseX,15,25 );
    text("Y: " + mouseY,15,40 );
  
  //Ememy shape
    fill(204,0,0);
    circle(enemyX, enemyY, 10);
  
  shapeXSpeed = Math.floor(Math.random() * (Math.floor(Math.random() * 5)) + 1);
     shapeYSpeed = Math.floor(Math.random() * (Math.floor(Math.random() * 5)) + 1);

    enemyX += shapeXSpeed;
    enemyY += shapeYSpeed;
  
  //Checks bounds
     if(enemyX > width)
    {
        enemyX = 0;
    }
    if(enemyX < 0)
    {
        enemyX = width;
    }
    if(enemyY > height)
    {
        enemyY = 0;
    }
    if(enemyY < 0)
    {
        enemyY = height;
    }
  
  //Circle (moving charater)
    strokeWeight(3);
    stroke(255);
    fill(126,175,162);
    circle(charX,charY,40);
  
  //Click to create a shape
  fill(120,130,140);
    circle(mousex, mousey, 25);
  
  //Checks if shape is out of the exit
  if(charX > width && charY > width-50)
    {
        fill(65,186,28);
        stroke(225);
        strokeWeight(1);
        textSize(26);
        text("You Win!", width/2-50, height/2-50);
    }
  
  //Movement (wasd keys)
      if (keyIsDown(83)) 
      {charY += 7;} 
  
      else if (keyIsDown(87)) 
      {charY -= 7;}

      if(keyIsDown(65))
      {charX-=7;}
  
      else if (keyIsDown(68))
      {charX+=7;}
}  
  function mouseClicked()
{
    mousex = mouseX;
    mousey = mouseY;
}  
 
