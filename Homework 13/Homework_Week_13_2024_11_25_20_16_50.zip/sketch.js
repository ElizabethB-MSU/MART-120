var charX = 250;
var charY = 300;

var enemyX = 50;
var enemyY = 50;

var width;
var height;

var x = 50;
var y = 50;
var diameter = 25;

var enemy2X = [];
var enemy2Y = [];
var enemyDiameters = [];

var shapeXSpeed = [];
var shapeYSpeed = [];

var mousex = 100;
var mousey = 650;

function getRandomNumber(number) {
  return Math.floor(Math.random() * number) + 10;
}

function setup() {
  createCanvas(500, 600);

  for (var i = 0; i < 10; i++) {
    shapeXSpeed = Math.floor(Math.random() * Math.floor(Math.random() * 5) + 1);
    shapeYSpeed = Math.floor(Math.random() * Math.floor(Math.random() * 5) + 1);
    enemyX[i] = getRandomNumber(350);
    enemyY[i] = getRandomNumber(600);
    enemyDiameters[i] = getRandomNumber(30);
  }
}

function draw() {
  background(100);
  stroke(50);
  fill(50);

  createBorder();
  createEnemy();
  controlCircle();
  createCircle();
  clickShape();
  winMessage();
}

function createCircle() {
  strokeWeight(3);
  stroke(255);
  fill(126, 175, 162);
  circle(charX, charY, 40);
}

function controlCircle() {
  if (keyIsDown(83)) {
    charY += 7;
  } else if (keyIsDown(87)) {
    charY -= 7;
  }

  if (keyIsDown(65)) {
    charX -= 7;
  } else if (keyIsDown(68)) {
    charX += 7;
  }
}

function clickShape() {
  fill(120, 130, 140);
  circle(mousex, mousey, 25);
}

function mouseClicked() {
  mousex = mouseX;
  mousey = mouseY;
}
function createBorder() {
  rect(0, 0, width, 10);
  rect(0, 0, 10, height);
  rect(0, height - 10, width, 10);
  rect(width - 10, 0, 10, height - 90);}

  function createEnemy() {
    fill(204, 0, 0);
  }

  for (var i = 0; i < enemyX.length; i++) {
    circle(enemyX, enemyY, enemyDiameters);
  }
  shapeXSpeed = Math.floor(Math.random() * Math.floor(Math.random() * 5) + 1);
  shapeYSpeed = Math.floor(Math.random() * Math.floor(Math.random() * 5) + 1);

  enemyX[i] += shapeXSpeed;
  enemyY[i] += shapeYSpeed;

  //Checks bounds
  if (enemyX > width) {
    enemyX = 0;
  }
  if (enemyX < 0) {
    enemyX = width;
  }
  if (enemyY > height) {
    enemyY = 0;
  }
  if (enemyY < 0) {
    enemyY = height;
}

function winMessage() {
  if (charX > width && charY > width - 50) {
    fill(65, 186, 28);
    stroke(225);
    strokeWeight(1);
    textSize(26);
    text("You Win!", width / 2 - 50, height / 2 - 50);
  }
}
